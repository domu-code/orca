#!/usr/bin/env python3
"""Check the exported Android build kit, especially Orca pattern dimensions."""
from pathlib import Path
import json

root = Path(__file__).resolve().parent.parent
assert (root/'.github/workflows/android-apk.yml').is_file()
assert (root/'app/src/main/assets/mobile/android-bridge.js').is_file()
for engine in ('plaits/dsp/voice.cc', 'rings/dsp/part.cc', 'beads/dsp/processor.cc'):
    assert (root/'app/src/main/cpp/eurorack'/engine).is_file(), engine
presets = root/'app/src/main/assets/presets'
index = json.loads((presets/'index.json').read_text())
assert len(index) == 40, f'Expected 40 presets, got {len(index)}'
assert {p['category'] for p in index} == {'Classic', 'Euclidean', 'Generative', 'Ambient / Polymeter'}
for preset in index:
    p = presets/preset['file']
    grid = p.read_text().splitlines()
    assert len(grid) == 28, (p, len(grid))
    assert all(len(line) == 80 for line in grid), p
    assert ':' in p.read_text(), p
    assert any(ch in p.read_text() for ch in 'DU'), p
    assert 'CRL' not in p.read_text(), p
print('ORCA Modular source kit: 40 full-size operator presets, 3 upstream DSP engines, build workflow present.')
