#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p app/src/main/assets
if [ ! -d upstream-orca/.git ]; then git clone --depth 1 https://github.com/hundredrabbits/Orca.git upstream-orca; fi
# Import the authentic browser Orca, including every script and resource.
rm -rf app/src/main/assets/orca
mkdir -p app/src/main/assets/orca
cp upstream-orca/index.html upstream-orca/manifest.json upstream-orca/sw.js upstream-orca/favicon.ico app/src/main/assets/orca/
cp -a upstream-orca/desktop app/src/main/assets/orca/
# Bundle project's original MIT license with the app for attribution.
cp upstream-orca/LICENSE.md app/src/main/assets/orca/ORCA_UPSTREAM_LICENSE.md
cp app/src/main/assets/mobile/android-bridge.js app/src/main/assets/orca/android-bridge.js
python3 - <<'PY2'
from pathlib import Path
# The Android interface replaces the Web MIDI device list and uses Android MidiManager.
# Disable the upstream Web MIDI discovery to avoid an asynchronous overwrite of our port.
midi=Path('app/src/main/assets/orca/desktop/sources/scripts/core/io/midi.js')
source=midi.read_text()
needle="    if (!navigator.requestMIDIAccess) { return }"
assert needle in source, "Unexpected upstream Orca MIDI source; recheck the bridge before building."
midi.write_text(source.replace(needle,"    if (window.OrcaAndroid) { return }\n"+needle,1))
index=Path('app/src/main/assets/orca/index.html')
html=index.read_text()
assert '</body>' in html
# A service worker offers no benefit in an offline APK and may cache stale assets.
html=html.replace("if (location.protocol.substr(0,4) !== ('file') && 'serviceWorker' in navigator)",
                  "if (!window.OrcaAndroid && location.protocol.substr(0,4) !== ('file') && 'serviceWorker' in navigator)")
html=html.replace('</body>', '<script src="android-bridge.js"></script>\n</body>')
index.write_text(html)
PY2
# Track the actual upstream Orca revision included in this APK.
git -C upstream-orca rev-parse HEAD > app/src/main/assets/orca/ORCA_UPSTREAM_COMMIT.txt
node --check app/src/main/assets/orca/android-bridge.js
