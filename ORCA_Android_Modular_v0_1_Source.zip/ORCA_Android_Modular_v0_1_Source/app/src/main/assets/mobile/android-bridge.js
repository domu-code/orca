'use strict';
// Loaded after the original, unmodified Orca interpreter scripts.
(function () {
  function attach() {
    if (!window.orcaClient || !window.OrcaAndroid) return;
    const client = window.orcaClient;
    const midi = client.io.midi;
    midi.refresh = function () {};
    midi.outputs = [{ name: 'Android router (internal + USB)', send: function (data) {
      try { window.OrcaAndroid.sendMidi(JSON.stringify(data)); } catch (err) { console.warn(err); }
    }}];
    midi.selectOutput(0);
    midi.toString = function () { return 'Android MIDI'; };
    midi.toOutputString = function () { return 'Android router'; };
    midi.toInputString = function () { return 'Android MIDI input'; };
    client.toggleGuide(false);
    client.update();
    window.OrcaMobile = {
      run: function (cmd) {
        const controls = {
          play: function () { client.clock.play(); if (window.OrcaMobileClockOut) client.io.midi.sendClockStart(); },
          stop: function () { client.clock.stop(); },
          panic: function () { client.io.silence();client.io.midi.allNotesOff(); },
          up: function () { client.cursor.move(0,1); },
          down: function () { client.cursor.move(0,-1); },
          left: function () { client.cursor.move(-1,0); },
          right: function () { client.cursor.move(1,0); },
          bang: function () { client.cursor.trigger(); },
          erase: function () { client.cursor.erase(); },
          zoomin: function () { client.modZoom(0.0625); },
          zoomout: function () { client.modZoom(-0.0625); },
          guide: function () { client.toggleGuide(); },
          insert: function () { client.cursor.ins = !client.cursor.ins; },
          newfile: function () { client.reset(); }
        };
        if (controls[cmd]) controls[cmd]();
        client.update();
      },
      write: function (chars) {
        String(chars).split('').forEach(function (ch) { client.cursor.write(ch); });
        client.update();
      },
      load: function (grid) {
        client.whenOpen({name:'mobile.orca'},grid);
        client.clock.setFrame(0);
        client.toggleGuide(false);
        client.update();
      },
      program: function () { return String(client.orca); },
      receive: function (data) { client.io.midi.receive({ data: data }); },
      clockOut: function (enabled) {
        window.OrcaMobileClockOut = !!enabled;
        if (enabled && !client.clock.isPaused) client.io.midi.sendClockStart();
        if (!enabled && client.io.midi.isClock) client.io.midi.sendClockStop();
      }
    };
    try { window.OrcaAndroid.ready(); } catch (err) { console.warn(err); }
  }
  window.addEventListener('load', function () { setTimeout(attach, 0); });
})();
