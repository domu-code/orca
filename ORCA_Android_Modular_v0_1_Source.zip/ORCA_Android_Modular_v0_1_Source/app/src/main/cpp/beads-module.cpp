#include "beads-module.h"
#include "beads/dsp/processor.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace ptfx {
struct BeadsModule::Impl {
    beads::Processor processor;
    uint8_t mainBuffer[512*1024]{},secondaryBuffer[256*1024]{};
    uint16_t reverbBuffer[32768]{};
    beads::FloatFrame input[12]{},queue[256]{};
    int parameters[13]{0,32,180,180,128,140,64,48,0,144,128,128,128};
    int inputCount=0,read=0,write=48;
    double inputPhase=0,outputPhase=0,step=1;
    float previous[2]{};
    void reset(float rate){
        std::memset(mainBuffer,0,sizeof(mainBuffer));std::memset(secondaryBuffer,0,sizeof(secondaryBuffer));
        std::memset(reverbBuffer,0,sizeof(reverbBuffer));
        for(auto& frame:queue)frame=0.f;
        inputCount=read=0;write=48;inputPhase=outputPhase=0;previous[0]=previous[1]=0;
        step=48000.0/std::max(8000.f,rate);
        uint8_t* buffers[]{mainBuffer,mainBuffer+256*1024,secondaryBuffer};
        processor.Init(buffers,reverbBuffer);processor.Configure(beads::Processor::MEDIA_DIGITAL,false);
    }
    static float unit(int v){return std::clamp(v,0,255)/255.f;}
    static float bipolar(int v){return v>=128?(v-128)/127.f:(v-128)/128.f;}
    void render(){
        beads::Parameters p{};
        beads::RandomizedParameter* param[]{&p.time,&p.size,&p.pitch,&p.shape};
        const int indices[]{1,2,4,5};
        for(int k=0;k<4;++k){param[k]->base=k==2?bipolar(parameters[indices[k]])*48.f:unit(parameters[indices[k]]);
            param[k]->attenuverter=bipolar(parameters[9+k]);param[k]->has_cv=false;param[k]->cv=0;}
        p.monophonic_mode=false;
        beads::ModulatedParameter density{unit(parameters[3]),0.f};
        beads::Processor::MixParameters mix{unit(parameters[6])*.94f,1.f,unit(parameters[7]),false};
        bool freeze[12];std::fill(freeze,freeze+12,parameters[8]!=0);
        beads::FloatFrame output[12]{};
        processor.Process(beads::SEED_BUTTON_STATE_LOCKED,nullptr,freeze,density,p,mix,input,output,12);
        for(const auto& frame:output){queue[write]=frame;write=(write+1)&255;}
        inputCount=0;
    }
};
BeadsModule::BeadsModule():impl(new Impl{}){impl->reset(44100.f);}
BeadsModule::~BeadsModule()=default;
void BeadsModule::reset(float rate){impl->reset(rate);}
void BeadsModule::set(const int* values){for(int k=0;k<13;++k)impl->parameters[k]=std::clamp(values[k],0,255);}
void BeadsModule::process(float* p,int frames,int channels){
    auto& s=*impl;
    const float wet=s.parameters[0]/255.f;
    if(wet<=0||channels<2)return;
    for(int i=0;i<frames;++i){
        const float dry[]{p[i*channels],p[i*channels+1]};
        s.inputPhase+=s.step;
        while(s.inputPhase>=1.0){
            s.inputPhase-=1.0;const float alpha=float(1.0-s.inputPhase/s.step);
            s.input[s.inputCount].l=s.previous[0]+(dry[0]-s.previous[0])*alpha;
            s.input[s.inputCount].r=s.previous[1]+(dry[1]-s.previous[1])*alpha;
            if(++s.inputCount==12)s.render();
        }
        const auto& a=s.queue[s.read];const auto& b=s.queue[(s.read+1)&255];
        const float left=a.l+(b.l-a.l)*float(s.outputPhase),right=a.r+(b.r-a.r)*float(s.outputPhase);
        p[i*channels]=dry[0]+wet*(left-dry[0]);p[i*channels+1]=dry[1]+wet*(right-dry[1]);
        s.outputPhase+=s.step;while(s.outputPhase>=1.0){s.outputPhase-=1.0;s.read=(s.read+1)&255;}
        s.previous[0]=dry[0];s.previous[1]=dry[1];
    }
}
}
