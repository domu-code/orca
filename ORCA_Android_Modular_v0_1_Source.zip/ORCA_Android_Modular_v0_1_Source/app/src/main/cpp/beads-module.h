#pragma once
#include <memory>

namespace ptfx {
class BeadsModule {
public:
    BeadsModule();
    ~BeadsModule();
    BeadsModule(const BeadsModule&)=delete;
    BeadsModule& operator=(const BeadsModule&)=delete;
    void reset(float sampleRate);
    // wet,time,size,density,pitch,shape,feedback,reverb,freeze, four attenurandomizers.
    void set(const int* values);
    void process(float* samples,int frames,int channels);
private:
    struct Impl;
    std::unique_ptr<Impl> impl;
};
}
