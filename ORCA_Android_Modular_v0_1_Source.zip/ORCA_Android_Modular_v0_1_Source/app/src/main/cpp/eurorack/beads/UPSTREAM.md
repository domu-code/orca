Beads DSP by Emilie Gillet, MIT license in each source file.
Source: https://github.com/pichenettes/eurorack
Commit: f4cfa7697095a28d292bff758beb51deb49b5a86
Fetched 2026-11-12. DSP files are unmodified. PocketTracker uses the stereo 48 kHz digital path with a host-rate streaming adapter. Hardware UI, codec, autosave and wavetable self-play are not included.
