package com.oll.orcamodular;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Iterator;
import java.util.Map;

final class SoundState {
    static final class Slot {
        int channel, engine=0, model=8;
        boolean enabled=true;
        float[] p={0.50f,0.50f,0.50f,0.50f,0.50f,0.72f,0.15f};
        JSONObject json() throws Exception {
            JSONObject o=new JSONObject();o.put("channel",channel).put("engine",engine)
                .put("model",model).put("enabled",enabled);
            JSONArray a=new JSONArray();for(float v:p)a.put(v);
            o.put("params",a);return o;
        }
        void from(JSONObject o){
            channel=Math.max(-1,Math.min(15,o.optInt("channel",channel)));
            engine=Math.max(0,Math.min(2,o.optInt("engine",engine)));
            model=Math.max(0,Math.min(23,o.optInt("model",model)));
            enabled=o.optBoolean("enabled",enabled);
            JSONArray a=o.optJSONArray("params");if(a!=null)for(int i=0;i<Math.min(p.length,a.length());i++)p[i]=clamp((float)a.optDouble(i,p[i]));
        }
    }
    final Slot[] slots=new Slot[4];
    final float[] fx={0.0f,0.30f,0.10f,0.12f,0.0f,0.0f,0.0f, 0.0f,0.35f,0.40f, 0.0f,0.60f, 0.0f,0.45f,0.40f, 0.50f,0.50f,0.50f,0.15f,0.20f,0.0f,0.50f,0.50f,0.50f,0.50f};
    final boolean[] fxEnabled={true,true,true,false};
    final Map<String,Integer> bindings=new ConcurrentHashMap<>();
    boolean internal=true,external=true,inputToSynth=true,inputClock=true,outputClock=false;
    SoundState(){
        for(int i=0;i<slots.length;i++){
            slots[i]=new Slot();slots[i].channel=i;
            if(i==1){slots[i].engine=1;slots[i].model=0;}
            if(i==2){slots[i].engine=0;slots[i].model=11;}
            if(i==3){slots[i].engine=2;slots[i].enabled=false;}
        }
        // Orca MIDI CC operator defaults to offset 64. CC learn can override each of these.
        bindings.put("fx.0",64); // tape wet
        bindings.put("fx.7",65); // delay wet
        bindings.put("fx.10",66); // reverb wet
        bindings.put("fx.12",67); // grains wet
        for(int i=0;i<4;i++){
            bindings.put("slot"+i+".1",(i<<8)|68);
            bindings.put("slot"+i+".2",(i<<8)|69);
            bindings.put("slot"+i+".3",(i<<8)|70);
        }
    }
    static float clamp(float v){return Math.max(0f,Math.min(1f,v));}
    JSONObject json() throws Exception{
        JSONObject o=new JSONObject();o.put("schema",1).put("internal",internal).put("external",external)
            .put("inputToSynth",inputToSynth).put("inputClock",inputClock).put("outputClock",outputClock);
        JSONArray s=new JSONArray();for(Slot slot:slots)s.put(slot.json());o.put("slots",s);
        JSONArray f=new JSONArray(),enabled=new JSONArray();for(float v:fx)f.put(v);for(boolean b:fxEnabled)enabled.put(b);
        o.put("fx",f).put("fxEnabled",enabled);
        JSONObject cc=new JSONObject();for(Map.Entry<String,Integer> e:bindings.entrySet())cc.put(e.getKey(),e.getValue());
        o.put("ccBindings",cc);return o;
    }
    void from(JSONObject o){
        internal=o.optBoolean("internal",internal);external=o.optBoolean("external",external);
        inputToSynth=o.optBoolean("inputToSynth",inputToSynth);inputClock=o.optBoolean("inputClock",inputClock);outputClock=o.optBoolean("outputClock",outputClock);
        JSONArray s=o.optJSONArray("slots");if(s!=null)for(int i=0;i<Math.min(slots.length,s.length());i++){
            JSONObject item=s.optJSONObject(i);if(item!=null)slots[i].from(item);
        }
        JSONArray f=o.optJSONArray("fx"),enabled=o.optJSONArray("fxEnabled");
        if(f!=null)for(int i=0;i<Math.min(fx.length,f.length());i++)fx[i]=clamp((float)f.optDouble(i,fx[i]));
        if(enabled!=null)for(int i=0;i<Math.min(fxEnabled.length,enabled.length());i++)fxEnabled[i]=enabled.optBoolean(i,fxEnabled[i]);
        JSONObject cc=o.optJSONObject("ccBindings");if(cc!=null){
            bindings.clear();Iterator<String> keys=cc.keys();
            while(keys.hasNext()){String key=keys.next();bindings.put(key,cc.optInt(key,-1));}
        }
    }
}
