package com.oll.orcamodular;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import androidx.webkit.WebViewAssetLoader;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Orca's original JavaScript sequencer + Android's MIDI and native Mutable DSP. */
public final class MainActivity extends Activity implements MidiIO.Listener {
    private static final int OPEN_FILE=101,SAVE_ORCA=102,SAVE_SESSION=103;
    private final int ink=Color.rgb(230,238,230),panel=Color.rgb(28,35,38),accent=Color.rgb(93,207,168);
    private WebView web;
    private TextView message;
    private EditText characterInput;
    private SharedPreferences prefs;
    private SoundState state;
    private Synth synth;
    private MidiIO midi;
    private boolean ready=false;
    private volatile String learnTarget=null;
    private String lastGrid="";
    
    private final String[] soundNames={"Harmonics / Structure","Timbre / Brightness","Morph / Damping","Decay / Position","LPG colour","Level","Aux blend"};
    private final String[] fxNames={"Tape wet","Tape drive","Tape wow","Tape flutter","Tape hiss","Tape wear","Tape feedback echo", "Delay wet","Delay feedback","Delay time", "Reverb wet","Reverb room", "Beads wet","Beads size","Beads density", "Beads time","Beads pitch","Beads shape","Beads feedback","Beads reverb","Beads freeze","Beads random time","Beads random size","Beads random pitch","Beads random shape"};
    private final String[] engineNames={"Plaits · original DSP","Rings · original DSP","Beads · pitch-controlled FX"};

    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs=getSharedPreferences("orca_modular_v1",MODE_PRIVATE);
        state=new SoundState();
        try{state.from(new JSONObject(prefs.getString("sound","{}")));}catch(Exception ignored){}
        synth=new Synth();midi=new MidiIO(this,this);
        applyAll();
        createUI();
    }

    private void createUI(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.BLACK);
        setContentView(root);
        HorizontalScrollView top=new HorizontalScrollView(this);top.setHorizontalScrollBarEnabled(false);
        LinearLayout toolbar=new LinearLayout(this);toolbar.setOrientation(LinearLayout.HORIZONTAL);toolbar.setPadding(dp(3),dp(2),dp(3),dp(2));toolbar.setBackgroundColor(panel);
        top.addView(toolbar);root.addView(top,new LinearLayout.LayoutParams(-1,dp(47)));
        button(toolbar,"PLAY",()->jsRun("play"));
        button(toolbar,"STOP",()->{jsRun("stop");synth.silence();});
        button(toolbar,"PRESETS",this::showPresets);
        button(toolbar,"SOUND",this::showSound);
        button(toolbar,"FX",this::showFxSelector);
        button(toolbar,"MIDI",this::showMidi);
        button(toolbar,"FILE",this::showFile);
        button(toolbar,"BPM",this::showTempo);
        button(toolbar,"GUIDE",()->jsRun("guide"));
        button(toolbar,"PANIC",this::panic);

        web=new WebView(this);
        web.setBackgroundColor(Color.BLACK);web.setFocusable(true);web.setFocusableInTouchMode(true);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.setWebChromeClient(new WebChromeClient());
        final WebViewAssetLoader loader=new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView w,WebResourceRequest request){
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){
                Uri u=r.getUrl();return !"appassets.androidplatform.net".equals(u.getHost());
            }
        });
        web.addJavascriptInterface(new AndroidBridge(),"OrcaAndroid");
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        web.loadUrl("https://appassets.androidplatform.net/assets/orca/index.html");

        HorizontalScrollView bottom=new HorizontalScrollView(this);bottom.setHorizontalScrollBarEnabled(false);
        LinearLayout shortcuts=new LinearLayout(this);shortcuts.setGravity(Gravity.CENTER_VERTICAL);shortcuts.setPadding(dp(3),0,dp(3),0);shortcuts.setBackgroundColor(panel);
        bottom.addView(shortcuts);root.addView(bottom,new LinearLayout.LayoutParams(-1,dp(50)));
        button(shortcuts,"◀",()->jsRun("left"));button(shortcuts,"▲",()->jsRun("up"));
        button(shortcuts,"▼",()->jsRun("down"));button(shortcuts,"▶",()->jsRun("right"));
        button(shortcuts,"*",()->jsWrite("*"));button(shortcuts,".",()->jsWrite("."));
        button(shortcuts,"ERASE",()->jsRun("erase"));button(shortcuts,"INS",()->jsRun("insert"));
        characterInput=new EditText(this);characterInput.setSingleLine(true);characterInput.setTextColor(ink);
        characterInput.setHintTextColor(0xff7e8f88);characterInput.setTextSize(14);characterInput.setHint("ORCA glyphs");
        characterInput.setTypeface(Typeface.MONOSPACE);
        shortcuts.addView(characterInput,new LinearLayout.LayoutParams(dp(128),dp(44)));
        button(shortcuts,"WRITE",()->{
            String chars=characterInput.getText().toString();if(!chars.isEmpty())jsWrite(chars);
            characterInput.setText("");web.requestFocus();
        });
        button(shortcuts,"ZOOM +",()->jsRun("zoomin"));button(shortcuts,"ZOOM -",()->jsRun("zoomout"));
        message=new TextView(this);message.setTextColor(0xff96aca4);message.setTextSize(11);
        message.setGravity(Gravity.CENTER_VERTICAL);message.setPadding(dp(9),0,dp(9),0);message.setBackgroundColor(Color.BLACK);
        message.setText("Loading original Orca... | Plug in a USB keyboard and USB MIDI interface using an OTG hub");
        root.addView(message,new LinearLayout.LayoutParams(-1,dp(24)));
    }
    private int dp(float value){return (int)(value*getResources().getDisplayMetrics().density+0.5f);}
    private Button button(LinearLayout bar,String label,Runnable action){
        Button b=new Button(this);b.setText(label);b.setTextSize(11);b.setAllCaps(false);
        b.setTextColor(ink);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));
        b.setOnClickListener(v->action.run());
        bar.addView(b,new LinearLayout.LayoutParams(-2,dp(44)));
        return b;
    }
    private TextView caption(String label){
        TextView t=new TextView(this);t.setText(label);t.setTextColor(ink);t.setTextSize(14);
        t.setPadding(dp(7),dp(9),dp(7),dp(4));return t;
    }
    private LinearLayout form(){
        LinearLayout l=new LinearLayout(this);l.setPadding(dp(16),dp(8),dp(16),dp(10));l.setOrientation(LinearLayout.VERTICAL);return l;
    }
    private ScrollView scroll(LinearLayout content){ScrollView s=new ScrollView(this);s.addView(content);return s;}
    private Switch switchRow(LinearLayout host,String label,boolean initial,java.util.function.Consumer<Boolean> onChange){
        Switch sw=new Switch(this);sw.setText(label);sw.setTextColor(ink);sw.setChecked(initial);
        host.addView(sw,new LinearLayout.LayoutParams(-1,dp(46)));
        sw.setOnCheckedChangeListener((v,b)->{onChange.accept(b);saveState();});return sw;
    }
    private Spinner spinner(LinearLayout host,String[] options,int selected,java.util.function.IntConsumer change){
        Spinner s=new Spinner(this);ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,options);
        s.setAdapter(a);s.setSelection(Math.min(options.length-1,Math.max(0,selected)));
        host.addView(s,new LinearLayout.LayoutParams(-1,dp(46)));
        s.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> parent,View view,int pos,long id){change.accept(pos);}
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent){}
        });return s;
    }
    private void slider(LinearLayout host,String label,int max,int current,java.util.function.IntConsumer onChange,String learn){
        LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);
        TextView text=caption(label+"   "+current);
        text.setTextSize(12);r.addView(text,new LinearLayout.LayoutParams(0,dp(43),1));
        if(learn!=null){
            Button map=new Button(this);map.setText("CC LEARN");map.setTextSize(9);map.setAllCaps(false);
            map.setOnClickListener(v->{learnTarget=learn;notifyUser("Move a MIDI CC to map "+label);});
            r.addView(map,new LinearLayout.LayoutParams(dp(95),dp(38)));
        }
        host.addView(r);
        SeekBar b=new SeekBar(this);b.setMax(max);b.setProgress(Math.max(0,Math.min(current,max)));
        host.addView(b,new LinearLayout.LayoutParams(-1,dp(30)));
        b.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar seek,int value,boolean from){
                if(!from)return;text.setText(label+"   "+value);onChange.accept(value);saveState();
            }
            @Override public void onStartTrackingTouch(SeekBar seek){}
            @Override public void onStopTrackingTouch(SeekBar seek){}
        });
    }
    private void applyAll(){for(int i=0;i<state.slots.length;i++)applySlot(i);applyFx();synth.enabled(state.internal);}
    private void applySlot(int i){
        SoundState.Slot s=state.slots[i];
        synth.patch(i,s.engine==1?1:0,s.model,s.model,
            s.p[0],s.p[1],s.p[2],s.p[3],s.p[4],s.p[0],s.p[1],s.p[2],s.p[3],s.p[5],s.p[6]);
        if(!s.enabled)synth.allOff(i);
    }
    private void applyFx(){
        float[] f=state.fx;
        synth.tape(f[0],f[1],f[2],f[3],f[4],f[5],f[6]);
        synth.fx(f,state.fxEnabled);
        synth.beadsParams(f);
    }
    private void saveState(){
        try{prefs.edit().putString("sound",state.json().toString()).apply();}
        catch(Exception e){notifyUser("Could not save sound settings: "+e.getMessage());}
    }
    private void notifyUser(String s){runOnUiThread(()->{if(message!=null)message.setText(s);});}
    private void runJS(String body){if(web!=null&&ready)web.post(()->web.evaluateJavascript(body,null));}
    private void jsRun(String c){runJS("window.OrcaMobile.run("+JSONObject.quote(c)+")");}
    private void jsWrite(String s){runJS("window.OrcaMobile.write("+JSONObject.quote(s)+")");}
    private void showSound(){
        String[] labels=new String[4];
        for(int i=0;i<4;i++){
            SoundState.Slot s=state.slots[i];
            labels[i]="SLOT "+(i+1)+" · "+engineNames[s.engine]+" · "+(s.channel<0?"Omni":"CH "+(s.channel+1))+(s.enabled?"":" · MUTED");
        }
        new AlertDialog.Builder(this).setTitle("Internal instruments · choose slot")
            .setItems(labels,(d,which)->showSlot(which)).setNegativeButton("Close",null).show();
    }
    private void showSlot(int index){
        SoundState.Slot s=state.slots[index];LinearLayout f=form();
        switchRow(f,"Instrument enabled",s.enabled,b->{s.enabled=b;applySlot(index);});
        f.addView(caption("Sound engine"));
        spinner(f,engineNames,s.engine,i->{s.engine=i;if(i==1&&s.model>5)s.model=0;applySlot(index);saveState();});
        f.addView(caption("Incoming note channel · multiple slots may share a channel"));
        String[] channels=new String[17];channels[0]="Omni (all MIDI channels)";
        for(int i=1;i<channels.length;i++)channels[i]="MIDI channel "+i;
        spinner(f,channels,s.channel+1,i->{s.channel=i-1;saveState();});
        slider(f,"Model (Plaits 0-23, Rings 0-5)",23,s.model,i->{s.model=i;applySlot(index);},"slot"+index+".model");
        for(int i=0;i<s.p.length;i++){
            final int k=i;slider(f,soundNames[i],100,(int)(s.p[i]*100),v->{s.p[k]=v/100f;applySlot(index);},"slot"+index+"."+i);
        }
        f.addView(caption("Plaits: models 0-23. Rings: 0-5. Grains uses incoming notes to retune the granular buffer, which needs audio from another slot."));
        new AlertDialog.Builder(this).setTitle("Sound slot "+(index+1))
            .setView(scroll(f)).setPositiveButton("Done",(d,w)->{saveState();showSound();}).show();
    }
    private void showFxSelector(){
        String[] names={"TAPE · wow / flutter / saturation","DELAY · feedback echo","REVERB · feedback network","BEADS · original DSP · granular"};
        new AlertDialog.Builder(this).setTitle("Master effects · independently bypassable")
            .setItems(names,(d,which)->showFx(which)).setNegativeButton("Done",null).show();
    }
    private void showFx(int n){
        LinearLayout f=form();
        String[] names={"Tape","Delay","Reverb","Grains"};
        switchRow(f,names[n]+" enabled",state.fxEnabled[n],b->{state.fxEnabled[n]=b;applyFx();});
        int[][] indexes={{0,1,2,3,4,5,6},{7,8,9},{10,11},{12,13,14,15,16,17,18,19,20,21,22,23,24}};
        for(int id:indexes[n])slider(f,fxNames[id],100,(int)(state.fx[id]*100),v->{state.fx[id]=v/100f;applyFx();},"fx."+id);
        if(n==3)f.addView(caption("Original Beads DSP: time, size, density, pitch, shape, feedback, reverb, freeze and four randomization attenuverters. Beads MIDI slot notes transpose grain pitch. Beads operates on other internal instruments audio."));
        if(n==0)f.addView(caption("Tape uses moving delay-line pitch modulation, saturation, degradation, hiss and feedback, carried over from the Android XY8 source."));
        new AlertDialog.Builder(this).setTitle(names[n]+" parameters").setView(scroll(f))
            .setPositiveButton("Done",(d,w)->{saveState();showFxSelector();}).show();
    }
    private void showMidi(){
        LinearLayout f=form();
        f.addView(caption("External output: "+midi.getOutputName()));
        f.addView(caption("External input: "+midi.getInputName()));
        Button out=button(f,"SELECT USB MIDI OUTPUT",this::selectMidiOutput);
        Button in=button(f,"SELECT USB MIDI INPUT",this::selectMidiInput);
        switchRow(f,"Internal audio engines",state.internal,b->{state.internal=b;synth.enabled(b);});
        switchRow(f,"Send Orca MIDI to connected external output",state.external,b->state.external=b);
        switchRow(f,"USB MIDI notes feed internal instruments",state.inputToSynth,b->state.inputToSynth=b);
        switchRow(f,"USB MIDI transport / clock controls Orca",state.inputClock,b->state.inputClock=b);
        switchRow(f,"Send MIDI clock / start / stop to USB output",state.outputClock,b->{
            state.outputClock=b;runJS("window.OrcaMobile.clockOut("+b+")");
        });
        Button reset=button(f,"RESET CC ASSIGNMENTS",()->{
            state.bindings.clear();learnTarget=null;saveState();notifyUser("CC assignments cleared");
        });
        f.addView(caption("CC LEARN is available beside each sound / FX control. Orca ! operators send CCs, by default beginning at CC64. MIDI channels 1-16 map to Orca channels 0-F."));
        new AlertDialog.Builder(this).setTitle("USB MIDI / routing").setView(scroll(f)).setPositiveButton("Done",null).show();
    }
    private void selectMidiOutput(){
        ArrayList<MidiIO.Endpoint> choices=midi.outputs();
        String[] names=new String[choices.size()+1];names[0]="None · internal audio only";
        for(int i=0;i<choices.size();i++)names[i+1]=choices.get(i).label;
        new AlertDialog.Builder(this).setTitle("Android MIDI output port")
            .setItems(names,(d,i)->midi.openOutput(i==0?null:choices.get(i-1))).show();
    }
    private void selectMidiInput(){
        ArrayList<MidiIO.Endpoint> choices=midi.inputs();
        String[] names=new String[choices.size()+1];names[0]="None";
        for(int i=0;i<choices.size();i++)names[i+1]=choices.get(i).label;
        new AlertDialog.Builder(this).setTitle("Android MIDI input port")
            .setItems(names,(d,i)->midi.openInput(i==0?null:choices.get(i-1))).show();
    }
    private void showPresets(){
        try{
            String txt=readAsset("presets/index.json");JSONArray manifest=new JSONArray(txt);
            String[] names=new String[manifest.length()];
            for(int i=0;i<manifest.length();i++){
                JSONObject o=manifest.getJSONObject(i);names[i]=o.getString("category")+"  |  "+o.getString("name");
            }
            new AlertDialog.Builder(this).setTitle("ORCA pattern library · "+names.length+" programs")
                .setItems(names,(dialog,pos)->{
                    try{
                        JSONObject o=manifest.getJSONObject(pos);
                        String grid=readAsset("presets/"+o.getString("file"));
                        loadGrid(grid);int bpm=o.getInt("bpm");
                        prefs.edit().putInt("bpm",bpm).apply();
                        runJS("orcaClient.clock.setSpeed("+bpm+","+bpm+",true)");
                        notifyUser("Loaded "+o.getString("name")+" · "+bpm+" BPM · notes routed by MIDI channel");
                    }catch(Exception e){notifyUser("Preset error: "+e.getMessage());}
                }).setNegativeButton("Cancel",null).show();
        }catch(Exception e){notifyUser("Preset library unavailable: "+e.getMessage());}
    }
    private String readAsset(String name) throws Exception{
        try(InputStream in=getAssets().open(name);ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
            return out.toString("UTF-8");
        }
    }
    private void showTempo(){
        LinearLayout f=form();slider(f,"Orca clock BPM",300,prefs.getInt("bpm",120),v->{int bpm=Math.max(60,v);prefs.edit().putInt("bpm",bpm).apply();runJS("orcaClient.clock.setSpeed("+bpm+","+bpm+",true)");},null);
        new AlertDialog.Builder(this).setTitle("Tempo · 60 to 300 BPM").setView(f).setPositiveButton("Done",null).show();
    }
    private void showFile(){
        String[] options={"Open .orca or .orcaMod.json", "Save original .orca pattern", "Save complete session (.orcaMod.json)", "New empty grid", "Restore last autosave"};
        new AlertDialog.Builder(this).setTitle("Projects").setItems(options,(d,which)->{
            switch(which){
                case 0:openFile();break;
                case 1:requestSave(false);break;
                case 2:requestSave(true);break;
                case 3:new AlertDialog.Builder(this).setMessage("Discard the current grid?")
                    .setPositiveButton("New",(d2,w)->jsRun("newfile")).setNegativeButton("Cancel",null).show();break;
                case 4:loadGrid(prefs.getString("grid",""));break;
            }
        }).show();
    }
    private void openFile(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,OPEN_FILE);
    }
    private void requestSave(boolean session){
        if(!ready)return;
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(session?"application/json":"text/plain");
        i.putExtra(Intent.EXTRA_TITLE,session?"my_orca_session.orcaMod.json":"my_pattern.orca");
        startActivityForResult(i,session?SAVE_SESSION:SAVE_ORCA);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        if(request==OPEN_FILE){
            try(InputStream in=getContentResolver().openInputStream(uri)){
                if(in==null)return;
                ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
                while((n=in.read(buf))!=-1)out.write(buf,0,n);
                String text=out.toString("UTF-8");
                if(text.trim().startsWith("{")&&text.contains("\"grid\"")){
                    JSONObject o=new JSONObject(text);JSONObject sound=o.optJSONObject("sound");
                    if(sound!=null){state.from(sound);applyAll();saveState();}
                    loadGrid(o.getString("grid"));
                    int tempo=Math.max(60,Math.min(300,o.optInt("bpm",120)));
                    runJS("orcaClient.clock.setSpeed("+tempo+","+tempo+",true)");
                    notifyUser("Session restored at "+tempo+" BPM");
                }else{loadGrid(text);notifyUser("Original .orca pattern loaded");}
            }catch(Exception e){notifyUser("Open error: "+e.getMessage());}
        }else if(request==SAVE_ORCA||request==SAVE_SESSION){
            final boolean session=request==SAVE_SESSION;
            getGrid((grid,bpm)->{
                try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){
                    if(out==null)throw new IOException("No writable document handle");
                    String result=session?new JSONObject().put("format","orcaMod").put("grid",grid).put("bpm",bpm).put("sound",state.json()).toString(2):grid;
                    out.write(result.getBytes(StandardCharsets.UTF_8));out.flush();
                    notifyUser(session?"Session saved (grid + sound routing)":"Standard .orca pattern saved");
                }catch(Exception e){notifyUser("Save failed: "+e.getMessage());}
            });
        }
    }
    private interface GridCallback{void received(String grid,int bpm);}
    private void getGrid(GridCallback cb){
        if(!ready){cb.received(lastGrid,prefs.getInt("bpm",120));return;}
        web.evaluateJavascript("JSON.stringify({grid:String(orcaClient.orca),bpm:orcaClient.clock.speed.value})",value->{
            String grid=lastGrid;int tempo=prefs.getInt("bpm",120);
            try{
                String payload=new JSONArray("["+value+"]").getString(0);
                JSONObject snapshot=new JSONObject(payload);
                grid=snapshot.getString("grid");tempo=snapshot.optInt("bpm",120);
            }catch(Exception e){notifyUser("Grid snapshot decode error: "+e.getMessage());}
            lastGrid=grid;cb.received(grid,tempo);
        });
    }
    private void loadGrid(String content){
        if(content==null||content.isEmpty())return;
        lastGrid=content;
        runJS("window.OrcaMobile.load("+JSONObject.quote(content)+")");
        prefs.edit().putString("grid",content).apply();
    }
    private void panic(){jsRun("panic");synth.silence();notifyUser("All notes off · internal voices silenced");}

    private void routeMidi(byte[] bytes,boolean fromExternal){
        if(bytes==null||bytes.length==0)return;
        int status=bytes[0]&255;
        if(status>=0xF8){
            if(fromExternal){
                if(state.inputClock)runJS("window.OrcaMobile.receive(["+status+"])");
            }else if(state.external)midi.send(bytes);
            return;
        }
        int type=status&0xF0,channel=status&15;
        if(!fromExternal&&state.external)midi.send(bytes);
        if(fromExternal&&!state.inputToSynth)return;
        if(type==0x90&&bytes.length>=3&&(bytes[2]&127)>0){
            int note=bytes[1]&127,velocity=bytes[2]&127;
            if(state.internal)for(int i=0;i<state.slots.length;i++){
                SoundState.Slot slot=state.slots[i];
                if(slot.enabled&&(slot.channel==-1||slot.channel==channel)){
                    if(slot.engine==2)synth.grainNote(note,velocity);
                    else synth.on(i,note,0,velocity,0.5f);
                }
            }
        }else if((type==0x80&&bytes.length>=2)||(type==0x90&&bytes.length>=3&&(bytes[2]&127)==0)){
            int note=bytes[1]&127;
            for(int i=0;i<state.slots.length;i++){
                SoundState.Slot slot=state.slots[i];
                if(slot.channel==-1||slot.channel==channel)synth.off(i,note);
            }
        }else if(type==0xB0&&bytes.length>=3){
            handleCC(channel,bytes[1]&127,bytes[2]&127);
        }
    }
    private void handleCC(int ch,int controller,int value){
        String learning=learnTarget;
        if(learning!=null){
            learnTarget=null;state.bindings.put(learning,(ch<<8)|controller);
            saveState();notifyUser("Mapped "+learning+" to MIDI ch "+(ch+1)+" CC "+controller);
            return;
        }
        for(Map.Entry<String,Integer> e:state.bindings.entrySet()){
            int binding=e.getValue();
            if(binding!=((ch<<8)|controller))continue;
            String k=e.getKey();
            try{
                if(k.startsWith("fx.")){
                    int n=Integer.parseInt(k.substring(3));
                    if(n>=0&&n<state.fx.length)state.fx[n]=value/127f;
                    applyFx();
                }else if(k.startsWith("slot")){
                    int dot=k.indexOf('.');int slot=Integer.parseInt(k.substring(4,dot));
                    if(slot<0||slot>=4)continue;
                    String field=k.substring(dot+1);
                    if(field.equals("model"))state.slots[slot].model=Math.round(value*23f/127f);
                    else{int p=Integer.parseInt(field);if(p>=0&&p<7)state.slots[slot].p[p]=value/127f;}
                    applySlot(slot);
                }
            }catch(Exception ignored){}
        }
    }
    @Override public void onMidi(byte[] msg){routeMidi(msg,true);}
    @Override public void notice(String status){notifyUser(status);}
    @Override public void portsChanged(){notifyUser("MIDI devices changed · open MIDI to select ports");}
    private final class AndroidBridge{
        @JavascriptInterface public void sendMidi(String message){
            try{
                JSONArray j=new JSONArray(message);byte[] data=new byte[j.length()];
                for(int i=0;i<data.length;i++)data[i]=(byte)(j.getInt(i)&255);
                routeMidi(data,false);
            }catch(Exception e){notifyUser("MIDI bridge: "+e.getMessage());}
        }
        @JavascriptInterface public void ready(){
            runOnUiThread(()->{
                ready=true;
                String restored=prefs.getString("grid","");
                if(!restored.isEmpty()){
                    loadGrid(restored);
                    int tempo=Math.max(60,Math.min(300,prefs.getInt("bpm",120)));
                    runJS("orcaClient.clock.setSpeed("+tempo+","+tempo+",true)");
                }else try{loadGrid(readAsset("presets/01_four_on_four.orca"));}catch(Exception ignored){}
                if(state.outputClock)runJS("window.OrcaMobile.clockOut(true)");
                notifyUser("ORCA JS active · original Plaits / Rings / Beads DSP · tape / FX · USB MIDI");
                web.requestFocus();
            });
        }
    }
    @Override protected void onPause(){
        if(ready)getGrid((grid,bpm)->{
            if(!grid.isEmpty())prefs.edit().putString("grid",grid).putInt("bpm",bpm).apply();
        });
        saveState();super.onPause();
    }
    @Override protected void onDestroy(){
        panic();midi.close();if(web!=null){web.destroy();web=null;}synth.destroy();
        super.onDestroy();
    }
}
