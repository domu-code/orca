# ORCA Modular for Android

**Android v0.2.0 | Bottom controls + monotonic timing | Single-ZIP GitHub build kit**

An experimental Android adaptation of **Hundred Rabbits' original JavaScript Orca** live-coding sequencer. The Orca language and main grid are retained, while a native Android wrapper provides MIDI routing, a USB keyboard workflow, native Mutable Instruments sound engines, effects, parameter pages, and a preset browser.

This is a **complete Android Studio source project and GitHub Actions build recipe**, **not a precompiled APK**. The complete native sound library has been compiled and linked in a Linux host test; a JNI smoke test rendered nonzero Plaits audio, mixed Rings into the buffer, and processed it through the Beads DSP without errors. The full Android APK has **not** been built, installed, or tested on an Android device. GitHub Actions is the proposed first Android compilation and integration check; it may reveal further issues.

## Build a sideloadable APK on GitHub (one ZIP only)

This project is intended for the existing `domu-code/orca` GitHub repository. Its `.github/workflows/android-apk.yml` workflow is updated separately in GitHub to expect the new source ZIP; you do not need to upload a hidden `.github` folder or hundreds of files.

1. Open <https://github.com/domu-code/orca>, choose **Add file > Upload files** and upload **`ORCA_Android_Modular_v0_2_Source.zip` without extracting or renaming it**.
2. Commit the uploaded ZIP to `main`. The existing GitHub Actions workflow detects the new ZIP and builds it. Alternatively open **Actions > Build ORCA Modular Android APK > Run workflow**.
3. On success open the run's Artifacts section, download **`ORCA-Modular-Android-v0.2-debug-APK`**, extract it and install the contained `app-debug.apk`.
4. Connect a USB HID keyboard and/or class-compliant USB MIDI interface using an OTG hub. Select Android MIDI ports from the bottom **MIDI** tab. Your prior v0.1 build remains available in its earlier successful GitHub Actions run as a rollback.

The ZIP contains the whole Android Studio project, including all Mutable Instruments DSP sources. GitHub Actions downloads the upstream Orca source during its build. Android Studio users can unpack the ZIP and run `bash scripts/fetch-orca.sh` before building.

## v0.2 changes: accessibility and transport stability

**Accessible bottom controls:** The former top PLAY / STOP / PRESETS / SOUND / FX / MIDI / FILE / BPM / GUIDE / PANIC row is now immediately below the Orca grid. A second horizontally scrollable row underneath contains cursor, writing, edit and zoom buttons. A compact status line remains below the rows. No interactive tabs touch the Android notification shade. On Android 11+ the view also reserves navigation bar inset space.

**Monotonic transport:** `ClockScheduler.java` runs at Android audio priority, measuring pulse and step deadlines against `System.nanoTime()`. It generates 24 MIDI clock pulses per quarter note (six per Orca 1/16-note step) without the original Web Worker `setInterval` or nested JavaScript `setTimeout` clock pulses. It uses absolute deadlines rather than accumulating the previous wake-up error.

**Note lookahead:** Each Orca step evaluates 24 milliseconds ahead of the scheduled deadline. The bridge carries exact nanosecond timestamps as decimal strings rather than JavaScript numbers; internal notes are queued until their deadline, and outbound USB MIDI is sent using Android MIDI's timestamp-aware `MidiInputPort.send` interface. Whether hardware MIDI drivers honour future timestamps varies by Android device.

**Reduced GUI pressure:** WebView canvas painting is coalesced to display refresh instead of synchronously redrawing on every timing event. The audio render chunk was reduced from 480 to 240 frames at 48 kHz, decreasing how long the native audio mutex is held per block. The clock reports skipped steps, clock pulses, late events, and dropped WebView ticks on the MIDI panel.

**Limits:** Orca's interpreter still runs on WebView's UI thread, and Plaits/Rings audio is still streamed through Android AudioTrack rather than Oboe/AAudio sample-accurate scheduling. Long UI stalls, CPU overload, and USB driver behaviour can still cause timing irregularities. This is a substantial scheduler improvement, not a measured guarantee of sample-accurate audio on an Android device.

## Core functionality included in the source

- **Original Orca grid and interpreter** embedded in a local, offline-capable Android WebView; two bottom control rows contain playback, preset/sound/FX/MIDI/file/BPM tabs, cursor, erase, insert and zoom. USB PC keyboard events are intended to go directly to the original Orca key handler; a touch toolbar and character-entry field are also provided.
- **40 Orca-format presets** divided into Classic, Euclidean, Generative, and Ambient/Polymeter groups. These include pulse sequencers, multi-channel patterns, Euclidean triggers, random melody generators, and longer polymetric arrangements. A preset can be edited as normal Orca code. The generated examples have been checked for proper 80-column, 28-row grids and structurally valid `D`, `U`, `R`, and `:` operators, but not yet verified in the running Android app.
- **Four note-routing slots**, each with independent enable/mute, MIDI input channel 1-16 or Omni, engine choice, model, and sound parameters. All sound slots receive standard MIDI note events generated by Orca. Default slots 1-3 are two Plaits and one Rings source; slot 4 is a disabled Beads pitch-controller slot.
- **Original Mutable Instruments Plaits DSP** (24 models) and **Rings DSP** (6 resonator models), with sound-model selection and parameter pages. They are native C++ code, not sampled approximations.
- **Original Mutable Instruments Beads DSP** used as an optional pitch-controllable granular **effect** that processes the internal synth audio. Parameters: wet level, size, density, time, pitch, shape, feedback, reverb, freeze, and four randomization controls. Beads note routing retunes granular pitch; it is not a separate pitched oscillator, and requires incoming instrument audio or previously recorded internal buffer audio.
- **FX pages with individual mute/bypass**: tape, delay, reverb, and Beads. Tape has moving-delay-line wow/flutter, saturation, hiss, wear/dropouts and feedback echo. It is the XY8 software tape implementation derived from our previous tape experiments, **not a binary-identical port of a different tape-processing project**.
- **Android MIDI device and port selection** using `android.media.midi`, for USB class-compliant interfaces and other MIDI devices exposed by Android, such as virtual or Bluetooth MIDI. A USB MIDI keyboard can trigger internal synth slots. Original Orca `:` and `%` operators generate notes; `!` sends CC; `?` sends pitch bend. Internal and external MIDI can be enabled separately.
- **MIDI clock input and output** enable switches, outbound start/stop, selectable external MIDI input/output ports, per-slot MIDI channels and CC learning. In v0.2, outbound clock is driven from an independent monotonic Android scheduler; external MIDI clock *input* still reaches Orca through the WebView bridge.
- **File access**: load and save standard `.orca` grid text; save and open `.orcaMod.json` sessions containing the grid, BPM, sound slots, enabled/bypassed FX, routing switches, and CC assignments. Sound configuration and the most recent grid are autosaved locally. Connected MIDI *device* selection needs to be made again when you reopen the app.

## How note and parameter assignment works

Orca's MIDI operator is `:channel octave note velocity length`. A simple first-channel C note is `:03Cf1`, and the character immediately above the `:` must receive a bang from a `D`/`U` operator or a `*` event. Orca's channel characters run from `0` to `f`, representing MIDI channels 1-16. For example, `:03Cf1` goes to channel 1, `:13Df1` goes to channel 2, etc.

Choose **SOUND > SLOT > Incoming note channel** to link a Plaits/Rings engine to a given Orca channel. You may link several slots to the same channel for stacked sounds or assign separate channels for a multitimbral setup. For Beads pitch control, choose **Beads** as an engine in one slot and enable that slot; also enable **FX > Beads** and increase **Beads wet**. Note events sent to the Beads slot retune the granular pitch around the Beads pitch setting.

Open **FX** or a sound slot and tap **CC LEARN** on a parameter, then move a physical MIDI controller or send an Orca `!` CC message. Mappings store the MIDI channel and CC number. Default Orca CC offset is 64; factory FX shortcuts are CC64 for tape wet, CC65 for delay wet, CC66 for reverb wet, CC67 for Beads wet on channel 1. They can be reassigned.

The app has separate enable/mute controls for all four slots, internal audio globally, outbound MIDI, and each effect individually. Bypassing one effect does not remove its saved settings.

## Source map

| Source | Purpose |
|---|---|
| `app/src/main/java/com/oll/orcamodular/MainActivity.java` | Landscape UI, preset picker, USB keyboard workflow, per-slot and FX parameter pages, `.orca` file I/O, CC learn, session files |
| `MidiIO.java` | Android USB/virtual MIDI ports and timestamp-aware event sending |
| `ClockScheduler.java` | Native Java monotonic 24-PPQN clock and queued note deadlines |
| `SoundState.java` | Persistent slot routing, parameters, FX, and CC assignments |
| `Synth.java` | Audio thread, Android AudioTrack, JNI bridge |
| `app/src/main/cpp/native_synth.cpp` | Voice allocation, original Plaits/Rings engines, native tape, reverb, delay, Beads routing |
| `app/src/main/cpp/beads-module.cpp` | Stereo Beads DSP wrapper and 48 kHz conversion |
| `app/src/main/cpp/eurorack/` | Preserved Mutable Instruments Plaits, Rings, stmlib and Beads DSP source |
| `app/src/main/assets/mobile/android-bridge.js` | Android-to-original-Orca MIDI, playback, edits, grid import/export |
| `app/src/main/assets/presets/` | Forty standard `.orca` files and manifest |
| `scripts/fetch-orca.sh` | Retrieves original upstream Orca and installs Android MIDI integration before packaging |
| `.github/workflows/android-apk.yml` | Debug APK CI build and artifact upload |
| `scripts/verify-kit.py` | Source and grid validation without Android toolchain |

## Testing status and limitations

**Tested here:** full native DSP source compiled and linked successfully with Clang/CMake on Linux, a JVM/JNI host test produced nonzero audio from Plaits and a Plaits/Rings mix with Beads processing enabled, the JavaScript bridge parsed with Node, and the preset files validated for dimensions and operator structure. The native host build is not an Android binary and is not included in the release ZIP.

**v0.2 still not tested:** Android APK compilation for the new release, hardware USB MIDI clock/notes, USB keyboard input, WebView latency under load, background timing, measured audio latency and correct musical output of all 40 presets. The older v0.1 APK did successfully compile on GitHub. The current audio path is **48 kHz, mono, 16-bit AudioTrack**, not Oboe/AAudio; that is an important latency limitation. Reverb and delay are basic native effects rather than hardware-equivalent models. MIDI routing is MIDI 1.0, not MIDI 2.0/UMP. For reliable live performance this needs an on-device timing and stability pass, and preferably an Oboe audio backend.

The original Orca web version supports some functions (OSC/UDP/network) differently from the Electron app. This build only integrates MIDI and internal DSP with Android; it does **not** claim native Android OSC/UDP support, audio recording input, or AU/VST plug-ins.

## Licensing and attribution

**Hundred Rabbits' Orca**: MIT licensed. Official source: <https://github.com/hundredrabbits/Orca>. The GitHub workflow copies its original `LICENSE.md` into the packaged assets. This project is a separate, unofficial Android adaptation.

**Plaits, Rings, Beads, stmlib DSP**: source by Émilie Gillet / Mutable Instruments and contributors, available under the original MIT copyright and licence notices in the bundled files. Official original DSP source: <https://github.com/pichenettes/eurorack>. The preserved DSP sources are original code with native integration wrappers, not official Mutable hardware firmware. No endorsement or hardware-equivalence is implied.

**ORCA Modular** is a working project name for this independent adaptation. Respect the original licences and project naming guidance before public redistribution.
