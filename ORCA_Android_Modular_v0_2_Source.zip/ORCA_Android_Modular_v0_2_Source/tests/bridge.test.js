'use strict';
const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
let nativeStarts=[], nativeStops=0, acks=0, timed=[], immediate=[], renders=0, runs=0, originalCleared=0;
const window = {
  addEventListener(event, fn){ if(event==='load') this.loadCallback=fn; },
  OrcaAndroid: {
    sendMidi: s=>immediate.push(JSON.parse(s)),
    sendMidiTimed: (s,t)=>timed.push({msg:JSON.parse(s),time:t}),
    startClock: n=>nativeStarts.push(n),
    stopClock: ()=>nativeStops++,
    acknowledgeTick: ()=>acks++,
    ready: ()=>{}
  }
};
const clock = {
  speed:{value:120,target:120}, isPaused:false,isPuppet:false,
  clearTimer(){originalCleared++;}, setTimer(){throw Error('Original worker restarted');},
  play(){this.isPaused=false;this.setTimer(this.speed.value);},
  stop(){this.isPaused=true;this.clearTimer();}, setFrame(){},
};
const midi = {
  sendClock(){throw Error('Web MIDI clock still active');},
  isClock:false,
  selectOutput(){},
  allNotesOff(){}, silence(){},
  outputs:[]
};
const client = {
 clock,
 io:{ midi, silence(){} },
 update(){renders++;},
 run(){runs++;midi.outputs[0].send([0x90,60,127]);},
 cursor:{move(){},trigger(){},erase(){},write(){}},
 toggleGuide(){},modZoom(){},whenOpen(){},reset(){}
};
window.orcaClient=client;
const ctx={window,console,setTimeout(fn){fn();},requestAnimationFrame(fn){fn();}};
vm.runInNewContext(fs.readFileSync(process.argv[2],'utf8'),ctx);
window.loadCallback();
assert.equal(originalCleared,1);
assert.deepEqual(nativeStarts,[120]);
window.OrcaMobile.nativeTick('123456789123456789');
assert.equal(runs,1);assert.equal(acks,1);
assert.equal(timed[0].time,'123456789123456789');
assert.deepEqual(timed[0].msg,[0x90,60,127]);
assert.equal(immediate.length,0);
window.OrcaMobile.run('stop');
assert.equal(nativeStops,1); // Java bridge is active only after installation
window.OrcaMobile.run('play');
assert.deepEqual(nativeStarts,[120,120]);
window.OrcaMobile.clockOut(true);
assert.equal(midi.isClock,true);
console.log('ORCA Android bridge: native clock takeover, timed MIDI, STOP/PLAY and acknowledgment passed');
