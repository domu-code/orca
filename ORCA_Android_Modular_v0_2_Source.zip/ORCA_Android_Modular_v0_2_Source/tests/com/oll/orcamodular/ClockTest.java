package com.oll.orcamodular;
import java.util.ArrayList;
import java.util.Collections;
public class ClockTest {
    public static void main(String[] args) throws Exception {
        ArrayList<Long> steps = new ArrayList<>(), pulses = new ArrayList<>(), late = new ArrayList<>();
        ClockScheduler clock = new ClockScheduler(new ClockScheduler.Listener() {
            @Override public void step(long due) { steps.add(due);clockSnapshotLate(late,due); }
            @Override public void pulse(long due) { pulses.add(due); }
            @Override public void transport(boolean started) {}
        });
        clock.start(120);
        Thread.sleep(1550);
        clock.stop();
        int st=steps.size(), p=pulses.size();
        for(int i=1;i<pulses.size();i++) if(Math.abs((pulses.get(i)-pulses.get(i-1))-20_833_333L)>2_000L) throw new RuntimeException("pulse drift " + i);
        for(int i=1;i<steps.size();i++) if(Math.abs((steps.get(i)-steps.get(i-1))-125_000_000L)>2_000L) throw new RuntimeException("step drift " + i);
        if(st<10||p<60)throw new RuntimeException("not enough steps/pulses " + st+" "+p);
        if(late.size()<st)throw new RuntimeException("missing diagnostics");
        System.out.println("120 BPM: "+st+" steps, "+p+" pulse deadlines; skipped: "+clock.diagnostics());
        int before=pulses.size();
        Thread.sleep(150);
        if(pulses.size()!=before)throw new RuntimeException("pulses after stop");
        clock.start(240);
        Thread.sleep(550);
        clock.stop();
        System.out.println("240 BPM additional pulse deadlines: "+(pulses.size()-before));
        clock.shutdown();
    }
    private static void clockSnapshotLate(ArrayList<Long> late,long when){late.add(when-System.nanoTime());}
}
