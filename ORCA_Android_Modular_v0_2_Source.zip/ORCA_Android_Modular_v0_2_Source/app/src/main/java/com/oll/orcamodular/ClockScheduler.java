package com.oll.orcamodular;

import android.os.Process;
import java.util.PriorityQueue;
import java.util.concurrent.locks.LockSupport;

/**
 * Monotonic Android transport. Six MIDI clock pulses per Orca step (24 PPQN).
 * Orca evaluates one step ahead of its audible deadline, so the Java MIDI
 * bridge can timestamp USB output and release internal note events on time.
 * The grid interpreter itself still runs in WebView on the UI thread.
 */
final class ClockScheduler {
    interface Listener {
        void step(long deadlineNanoseconds);
        void pulse(long deadlineNanoseconds);
        void transport(boolean started);
    }

    static final long STEP_LOOKAHEAD_NS = 24_000_000L;
    private static final long MIDI_LOOKAHEAD_NS = 4_000_000L;
    private static final long WAKE_EARLY_NS = 350_000L;
    private static final long SLEEP_LIMIT_NS = 8_000_000L;
    private final Object mutex = new Object();
    private final PriorityQueue<Event> events = new PriorityQueue<>((a,b)->{int c=Long.compare(a.time,b.time);return c!=0?c:Long.compare(a.order,b.order);});
    private final Listener listener;
    private final Thread clockThread;
    private boolean alive=true, playing=false;
    private long pulseIntervalNs=20_833_333L;
    private long nextStepNs, nextPulseNs;
    private long sequence=0;
    private long skippedPulses=0, skippedSteps=0, lateEvents=0;

    private static final class Event {
        final long time, order;
        final Runnable action;
        Event(long time,long order,Runnable action){this.time=time;this.order=order;this.action=action;}
    }
    ClockScheduler(Listener listener){
        this.listener=listener;
        clockThread=new Thread(this::loop,"ORCA-Monotonic-Clock");
        clockThread.setDaemon(true);
        clockThread.start();
    }
    private static long intervalFor(int bpm){
        return Math.round(60_000_000_000.0/(Math.max(60,Math.min(300,bpm))*24.0));
    }
    void start(int bpm){
        boolean doStart=false;
        synchronized(mutex){
            long now=System.nanoTime();
            long next=intervalFor(bpm);
            if(!playing){
                playing=true;
                doStart=true;
                pulseIntervalNs=next;
                nextPulseNs=now+STEP_LOOKAHEAD_NS+16_000_000L;
                nextStepNs=nextPulseNs;
            }else if(next!=pulseIntervalNs){
                long old=pulseIntervalNs;
                // Preserve the fractional remaining beat when tempo changes.
                nextPulseNs=now+Math.max(1,(nextPulseNs-now)*next/old);
                nextStepNs=now+Math.max(1,(nextStepNs-now)*next/old);
                pulseIntervalNs=next;
            }
        }
        if(doStart)listener.transport(true);
        LockSupport.unpark(clockThread);
    }
    void stop(){
        boolean wasPlaying;
        synchronized(mutex){
            wasPlaying=playing;
            playing=false;
            events.clear();
        }
        LockSupport.unpark(clockThread);
        if(wasPlaying)listener.transport(false);
    }
    boolean isPlaying(){synchronized(mutex){return playing;}}
    void schedule(long nanoTime,Runnable action){
        if(action==null)return;
        if(nanoTime<=0){action.run();return;}
        synchronized(mutex){
            if(!playing)return;
            events.add(new Event(nanoTime,sequence++,action));
        }
        LockSupport.unpark(clockThread);
    }
    String diagnostics(){
        synchronized(mutex){return "skipped steps "+skippedSteps+", skipped clock pulses "+skippedPulses+", late events "+lateEvents;}
    }
    void shutdown(){
        stop();
        synchronized(mutex){alive=false;events.clear();}
        LockSupport.unpark(clockThread);
        try{clockThread.join(1000);}catch(InterruptedException e){Thread.currentThread().interrupt();}
    }
    private void loop(){
        try{Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);}
        catch(SecurityException ignored){}
        while(true){
            Runnable action=null;
            long wakeTime=Long.MAX_VALUE;
            int kind=0;
            long time=0;
            synchronized(mutex){
                if(!alive)return;
                long now=System.nanoTime();
                if(playing){
                    long stepTrigger=nextStepNs-STEP_LOOKAHEAD_NS;
                    long pulseTrigger=nextPulseNs-MIDI_LOOKAHEAD_NS;
                    if(stepTrigger<=now){
                        kind=1;time=nextStepNs;
                        long stepPeriod=pulseIntervalNs*6;
                        nextStepNs+=stepPeriod;
                        if(nextStepNs-STEP_LOOKAHEAD_NS<=now){
                            long missed=(now-(nextStepNs-STEP_LOOKAHEAD_NS))/stepPeriod+1;
                            nextStepNs+=missed*stepPeriod;
                            skippedSteps+=missed;
                        }
                    }else if(!events.isEmpty()&&events.peek().time<=now){
                        Event e=events.poll();
                        kind=3;time=e.time;action=e.action;
                        if(now-e.time>2_000_000L)lateEvents++;
                    }else if(pulseTrigger<=now){
                        kind=2;time=nextPulseNs;
                        nextPulseNs+=pulseIntervalNs;
                        if(nextPulseNs-MIDI_LOOKAHEAD_NS<=now){
                            long missed=(now-(nextPulseNs-MIDI_LOOKAHEAD_NS))/pulseIntervalNs+1;
                            nextPulseNs+=missed*pulseIntervalNs;
                            skippedPulses+=missed;
                        }
                    }else{
                        wakeTime=Math.min(stepTrigger,pulseTrigger);
                        if(!events.isEmpty())wakeTime=Math.min(wakeTime,events.peek().time);
                    }
                }else if(!events.isEmpty()){
                    // No stale notes after STOP; events are normally cleared by stop().
                    events.clear();
                }
            }
            switch(kind){
                case 1: listener.step(time);break;
                case 2: listener.pulse(time);break;
                case 3: try{action.run();}catch(Exception ignored){}break;
                default:
                    long sleep=wakeTime-System.nanoTime()-WAKE_EARLY_NS;
                    if(sleep>0)LockSupport.parkNanos(Math.min(sleep,SLEEP_LIMIT_NS));
                    else if(wakeTime==Long.MAX_VALUE)LockSupport.parkNanos(SLEEP_LIMIT_NS);
                    else Thread.yield();
            }
        }
    }
}
