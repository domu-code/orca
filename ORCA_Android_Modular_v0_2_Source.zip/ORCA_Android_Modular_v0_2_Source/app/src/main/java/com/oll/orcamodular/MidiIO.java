package com.oll.orcamodular;

import android.content.Context;
import android.media.midi.MidiDevice;
import android.media.midi.MidiDeviceInfo;
import android.media.midi.MidiInputPort;
import android.media.midi.MidiOutputPort;
import android.media.midi.MidiManager;
import android.media.midi.MidiReceiver;
import android.os.Handler;
import android.os.Looper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

/** Class-compliant USB/virtual/BLE MIDI, provided by Android's MIDI service. */
final class MidiIO {
    interface Listener { void onMidi(byte[] msg); void notice(String message); void portsChanged(); }
    static final class Endpoint {
        final MidiDeviceInfo device;
        final int port;
        final String label;
        Endpoint(MidiDeviceInfo device,int port,String label){this.device=device;this.port=port;this.label=label;}
    }
    private final MidiManager manager;
    private final Listener listener;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private MidiDevice outputDevice,inputDevice;
    private MidiInputPort outputPort;
    private MidiOutputPort inputPort;
    private volatile String outputName="None",inputName="None";
    MidiIO(Context context,Listener listener){
        this.listener=listener;
        manager=(MidiManager)context.getSystemService(Context.MIDI_SERVICE);
        if(manager!=null)manager.registerDeviceCallback(new MidiManager.DeviceCallback(){
            @Override public void onDeviceAdded(MidiDeviceInfo info){listener.portsChanged();}
            @Override public void onDeviceRemoved(MidiDeviceInfo info){listener.portsChanged();}
        },handler);
    }
    ArrayList<Endpoint> outputs(){return list(MidiDeviceInfo.PortInfo.TYPE_INPUT);}
    ArrayList<Endpoint> inputs(){return list(MidiDeviceInfo.PortInfo.TYPE_OUTPUT);}
    ArrayList<Endpoint> list(int type){
        ArrayList<Endpoint> result=new ArrayList<>();if(manager==null)return result;
        for(MidiDeviceInfo d:manager.getDevices()){
            String name=d.getProperties().getString(MidiDeviceInfo.PROPERTY_NAME);
            if(name==null||name.trim().isEmpty())name="MIDI device "+d.getId();
            for(MidiDeviceInfo.PortInfo p:d.getPorts())if(p.getType()==type){
                result.add(new Endpoint(d,p.getPortNumber(),name+" · port "+(p.getPortNumber()+1)));
            }
        }
        return result;
    }
    void openOutput(Endpoint endpoint){
        closeOutput();if(endpoint==null){listener.notice("MIDI output disconnected");return;}
        manager.openDevice(endpoint.device,d->{
            if(d==null){listener.notice("Unable to open MIDI output");return;}
            MidiInputPort p=d.openInputPort(endpoint.port);
            if(p==null){try{d.close();}catch(IOException ignored){}listener.notice("Output port unavailable");return;}
            synchronized(this){outputDevice=d;outputPort=p;outputName=endpoint.label;}
            listener.notice("MIDI OUT: "+endpoint.label);
        },handler);
    }
    void openInput(Endpoint endpoint){
        closeInput();if(endpoint==null){listener.notice("MIDI input disconnected");return;}
        manager.openDevice(endpoint.device,d->{
            if(d==null){listener.notice("Unable to open MIDI input");return;}
            MidiOutputPort p=d.openOutputPort(endpoint.port);
            if(p==null){try{d.close();}catch(IOException ignored){}listener.notice("Input port unavailable");return;}
            p.connect(receiver);
            synchronized(this){inputDevice=d;inputPort=p;inputName=endpoint.label;}
            listener.notice("MIDI IN: "+endpoint.label);
        },handler);
    }
    private final MidiReceiver receiver=new MidiReceiver(){
        int status=0,needed=0,used=0;
        final int[] data=new int[2];
        @Override public void onSend(byte[] bytes,int offset,int count,long timestamp){
            for(int i=offset;i<offset+count;i++){
                int b=bytes[i]&255;
                if(b>=0xF8){listener.onMidi(new byte[]{(byte)b});continue;}
                if(b>=0x80){
                    if(b>=0xF0){status=0;needed=used=0;continue;}
                    status=b;used=0;int hi=b&0xF0;needed=(hi==0xC0||hi==0xD0)?1:2;
                    continue;
                }
                if(status==0||needed==0)continue;
                data[used++]=b&127;
                if(used==needed){
                    byte[] msg=needed==1?new byte[]{(byte)status,(byte)data[0]}:new byte[]{(byte)status,(byte)data[0],(byte)data[1]};
                    listener.onMidi(msg);used=0;
                }
            }
        }
    };
    void send(byte[] msg){sendAt(msg,0);}
    synchronized void sendAt(byte[] msg,long nanoTime){
        if(outputPort==null||msg==null||msg.length==0)return;
        try{outputPort.send(msg,0,msg.length,nanoTime>0?nanoTime:0L);}
        catch(IOException e){listener.notice("MIDI send error: "+e.getMessage());}
    }
    synchronized void closeOutput(){
        try{if(outputPort!=null)outputPort.close();}catch(IOException ignored){}
        try{if(outputDevice!=null)outputDevice.close();}catch(IOException ignored){}
        outputPort=null;outputDevice=null;outputName="None";
    }
    synchronized void closeInput(){
        try{if(inputPort!=null){inputPort.disconnect(receiver);inputPort.close();}}catch(IOException ignored){}
        try{if(inputDevice!=null)inputDevice.close();}catch(IOException ignored){}
        inputPort=null;inputDevice=null;inputName="None";
    }
    void close(){closeInput();closeOutput();}
    String getOutputName(){return outputName;}
    String getInputName(){return inputName;}
}
