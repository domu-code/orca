'use strict';
// Original Orca interpreter and operators, with Android monotonic transport.
(function () {
  function attach() {
    if (!window.orcaClient || !window.OrcaAndroid) return;
    const client = window.orcaClient;
    const midi = client.io.midi;

    // Cancel the upstream Web Worker timer before installing the Android clock.
    client.clock.clearTimer();
    client.clock.setTimer = function (bpm) {
      this.timer = { androidClock: true };
      window.OrcaAndroid.startClock(Math.max(60, Math.min(300, Math.round(bpm))));
    };
    client.clock.clearTimer = function () {
      this.timer = null;
      window.OrcaAndroid.stopClock();
    };

    // Android sends six accurately scheduled MIDI pulses per Orca step.
    // Never let the original six JS setTimeout timers send duplicate pulses.
    midi.sendClock = function () {};
    midi.sendClockStart = function () { midi.isClock = true; };
    midi.sendClockStop = function () { midi.isClock = false; };
    midi.refresh = function () {};

    let stepDeadline = null;
    midi.outputs = [{ name: 'Android router (internal + USB)', send: function (data) {
      try {
        if (stepDeadline !== null) {
          window.OrcaAndroid.sendMidiTimed(JSON.stringify(data), stepDeadline);
        } else {
          window.OrcaAndroid.sendMidi(JSON.stringify(data));
        }
      } catch (err) { console.warn(err); }
    }}];
    midi.selectOutput(0);
    midi.toString = function () { return 'Android MIDI'; };
    midi.toOutputString = function () { return 'Android router'; };
    midi.toInputString = function () { return 'Android MIDI input'; };

    // The heavy canvas draw is synchronized to display refresh, rather than
    // occurring synchronously inside every sequencer tick.
    const originalUpdate = client.update.bind(client);
    let drawPending = false;
    client.update = function () {
      if (drawPending) return;
      drawPending = true;
      requestAnimationFrame(function () {
        drawPending = false;
        originalUpdate();
      });
    };

    client.toggleGuide(false);
    client.update();
    window.OrcaMobileClockOut = false;
    window.OrcaMobile = {
      nativeTick: function (deadline) {
        try {
          if (!client.clock.isPaused && !client.clock.isPuppet) {
            stepDeadline = String(deadline);
            client.run();
          }
        } finally {
          stepDeadline = null;
          window.OrcaAndroid.acknowledgeTick();
        }
      },
      run: function (cmd) {
        const controls = {
          play: function () { client.clock.play(); },
          stop: function () { client.clock.stop(); },
          panic: function () { client.io.silence(); client.io.midi.allNotesOff(); },
          up: function () { client.cursor.move(0, 1); },
          down: function () { client.cursor.move(0, -1); },
          left: function () { client.cursor.move(-1, 0); },
          right: function () { client.cursor.move(1, 0); },
          bang: function () { client.cursor.trigger(); },
          erase: function () { client.cursor.erase(); },
          zoomin: function () { client.modZoom(0.0625); },
          zoomout: function () { client.modZoom(-0.0625); },
          guide: function () { client.toggleGuide(); },
          insert: function () { client.cursor.ins = !client.cursor.ins; },
          newfile: function () { client.reset(); }
        };
        if (controls[cmd]) controls[cmd]();
        client.update();
      },
      write: function (chars) {
        String(chars).split('').forEach(function (ch) { client.cursor.write(ch); });
        client.update();
      },
      load: function (grid) {
        client.whenOpen({ name: 'mobile.orca' }, grid);
        client.clock.setFrame(0);
        client.toggleGuide(false);
        client.update();
      },
      program: function () { return String(client.orca); },
      receive: function (data) { client.io.midi.receive({ data: data }); },
      clockOut: function (enabled) {
        window.OrcaMobileClockOut = !!enabled;
        midi.isClock = !!enabled;
      }
    };

    // The original client.start() ran before this bridge was installed.
    // Resume the already-running transport with the new Android scheduler.
    if (!client.clock.isPaused && !client.clock.isPuppet) {
      client.clock.setTimer(client.clock.speed.value);
    }
    try { window.OrcaAndroid.ready(); } catch (err) { console.warn(err); }
  }
  window.addEventListener('load', function () { setTimeout(attach, 0); });
})();
